CREATE TRIGGER UpdateMaintenanceDateOnService
ON Maintenance
AFTER INSERT
AS
BEGIN
    DECLARE @IdMaintenance INT, @IdPlot INT, @DateOfService DATE, @IsFirstUpdate BIT = 0;

    SELECT @IdMaintenance = IdMaintenance, @IdPlot = IdPlot, @DateOfService = DateOfService
    FROM inserted;

    -- Check if the current DateOfService is NULL (first-time update)
    IF @DateOfService IS NULL
        SET @IsFirstUpdate = 1;

    -- Perform the primary update on the current Maintenance record
    UPDATE Maintenance
    SET DateOfService = @DateOfService
    WHERE IdMaintenance = @IdMaintenance;

    -- Check if the update was successful
    IF @@ROWCOUNT = 0
    BEGIN
        -- Throw an error if the update failed
            DECLARE @ErrorMessage NVARCHAR(MAX);
SET @ErrorMessage = 'Maintenance update failed for IdMaintenance: ' + ISNULL(CAST(@IdMaintenance AS NVARCHAR(MAX)), '');
THROW 50000, @ErrorMessage, 1;

        -- Rollback the transaction (prevent the update on the current record)
        ROLLBACK;
        RETURN;
    END;

    -- Find the most recent DateOfService for the same plot
    DECLARE @LatestMaintenanceDate DATE;
    SELECT @LatestMaintenanceDate = MAX(DateOfService)
    FROM Maintenance
    WHERE IdPlot = @IdPlot;

    -- Update the most recent DateOfService for the plot with conditional logic
    IF @LatestMaintenanceDate IS NOT NULL AND @IsFirstUpdate = 0
    BEGIN
        UPDATE Maintenance
        SET DateOfService = @LatestMaintenanceDate
        WHERE IdPlot = @IdPlot AND IdMaintenance <> @IdMaintenance;
    END;

    -- Additional non-trivial logic can be added here

END;
go

