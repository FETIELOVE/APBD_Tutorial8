CREATE PROCEDURE GetEmployeeInfoWithPosition
    @EmployeeID INT
AS
BEGIN
    -- Instruction 1: Retrieve Basic Employee Information
    SELECT
        e.Person_IdPerson,
        e.Telephone AS EmployeeTelephone,
        e.EmailAddress AS EmployeeEmail,
        p.FirstName,
        p.LastName,
        p.Gender,
        p.DateOfBirth,
        p.Address
    FROM
        Employee e
        INNER JOIN Person p ON e.Person_IdPerson = p.IdPerson
    WHERE
        e.Person_IdPerson = @EmployeeID;

    -- Instruction 2: Retrieve Current Position Details
    SELECT
        ep.StartDate AS CurrentPositionStartDate,
        pos.Position AS CurrentPosition,
        pos.Salary AS CurrentSalary
    FROM
        EmployeePosition ep
        LEFT JOIN Position pos ON ep.Position_IdPosition = pos.IdPosition
    WHERE
        ep.EmployeeId = @EmployeeID
        AND ep.StartDate = (SELECT MAX(StartDate) FROM EmployeePosition WHERE EmployeeId = @EmployeeID);

    -- Instruction 3: Retrieve Position History (excluding the current position)
    SELECT
        ep.StartDate AS PositionStartDate,
        ep.EndDate AS PositionEndDate,
        pos.Position,
        pos.Salary
    FROM
        EmployeePosition ep
        LEFT JOIN Position pos ON ep.Position_IdPosition = pos.IdPosition
    WHERE
        ep.EmployeeId = @EmployeeID
        AND ep.StartDate != (SELECT MAX(StartDate) FROM EmployeePosition WHERE EmployeeId = @EmployeeID)
    ORDER BY
        ep.StartDate DESC;
END;
go

