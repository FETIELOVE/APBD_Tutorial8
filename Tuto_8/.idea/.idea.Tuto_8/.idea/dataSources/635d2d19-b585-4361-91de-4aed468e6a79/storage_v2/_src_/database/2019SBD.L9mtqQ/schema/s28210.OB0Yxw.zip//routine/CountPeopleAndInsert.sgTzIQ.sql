
CREATE PROCEDURE CountPeopleAndInsert
AS
BEGIN
    DECLARE @ExistingCount INT
    DECLARE @NewId INT

    -- Count the number of people in EMP table
    SELECT @ExistingCount = COUNT(*) FROM EMP

    IF @ExistingCount < 7
    BEGIN
        -- Get the maximum existing id + 1
        SELECT @NewId = ISNULL(MAX(EMPNO), 0) + 1 FROM EMP
        
        -- Insert new person if count is less than 7
        INSERT INTO EMP (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO)
        VALUES (@NewId, 'Bob', 'Brown', NULL, GETDATE(), 0, NULL, 10)
        PRINT 'New person "Bob Brown" added with ID: ' + CAST(@NewId AS VARCHAR(10))
    END
    ELSE
    BEGIN
        PRINT 'No new person inserted. There are already 7 or more people.'
    END
END
go

